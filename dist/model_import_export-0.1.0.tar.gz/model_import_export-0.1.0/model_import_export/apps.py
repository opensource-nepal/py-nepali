from django.apps import AppConfig


class ModelImportExportConfig(AppConfig):
    name = 'model_import_export'
